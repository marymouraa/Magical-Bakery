<!DOCTYPE html>
<html>
<head>
    <title>Menu do Usuário</title>
    
    <link rel="stylesheet" href="../assets/css/menu.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="menu">
        <div class="user-info dropdown">
            <div class="user-photo">
            <link href="../assets/img/logojanela.png" rel="icon">
            </div>          
              <div class="user-photo">
                <img src="../assets/img/usuario1.png" alt="Foto do Usuário">
            </div><br>
            <div class="user-name">Nome do Usuário</div>
            <div class="dropdown-content">
                <!-- Conteúdo do dropdown -->
                <a class="dropdown-item" href="../visao/admin.html">Configurações</a>
                <a class="dropdown-item" href="../visao/login.php" onclick="logout()">Sair</a>
            </div>
    <script>
        function logout() {
        // Aqui você pode adicionar lógica para encerrar a sessão, por exemplo:
        // session_start();
        <?php session_destroy(); ?>

        // Redireciona para a página de login
        window.location.href = '../index.php';
    }
    </script>
</body>
</html>
