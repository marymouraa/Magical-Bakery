var preco = $('#preco').maskMoney()
