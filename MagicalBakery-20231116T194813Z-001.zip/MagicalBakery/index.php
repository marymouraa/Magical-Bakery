<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Magical Bakery</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
<!--   <div class="user-photo">
      <img src="assets/img/logo.png">
  </div> -->

  <!-- Favicons -->
  <link href="assets/img/logojanela.png" rel="icon">
  

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=https://fonts.googleapis.com/css?family=Inconsolata:400,500,600,700|Raleway:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/index.css" rel="stylesheet">

</head>

<body>


  <!-- ======= Navbar ======= -->
  <div class="collapse navbar-collapse custom-navmenu" id="main-navbar">
    <div class="container py-2 py-md-5">
      <div class="row align-items-start">
        <div class="col-md-2">
          <ul class="custom-menu">
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="visao/login.php">Login</a></li>
            <li><a href="visao/cadastrar-produto.php">Cadastrar Produtos</a></li>
          </ul>
        </div>
        <div class="col-md-6 d-none d-md-block  mr-auto">
          <div class="tweet d-flex">
            <span class="bi bi-twitter text-white mt-2 mr-3"></span>
            <div>
              <p><em> <br> @MagicalBakery<a href="#">t.co/v82jsk</a></em></p>
            </div>
          </div>
        </div>
        <div class="col-md-4 d-none d-md-block">
        <li><a href="visao/menu.php">Usuário</a></li>
        <li><a href="visao/editar-produto.php">Editar Produtos</a></li>
        </div>
      </div>

    </div>
  </div>

  <nav class="navbar navbar-light custom-navbar">
    <div class="container">
      <a class="navbar-brand" href="index.php"></a>
      <a href="#" class="burger" data-bs-toggle="collapse" data-bs-target="#main-navbar">
        <span></span>
      </a>
    </div>
  </nav>
  <div class="image-container">
        <img src="assets/img/logo.png" alt="Descrição da imagem">
          </div><br>

  <main id="main">
    <!-- ======= Works Section ======= -->
    <section class="section site-portfolio">
      <div class="container">
        <div class="row mb-5 align-items-center">
          <div class="col-md-12 col-lg-6 mb-4 mb-lg-0" data-aos="fade-up">
            <h2>Bem-vindo a nossa confeitaria artesnal</h2>
            <p class="mb-0">Feito com amor & servido com duçura</p>
          </div>
          <div class="col-md-12 col-lg-6 text-start text-lg-end" data-aos="fade-up" data-aos-delay="100">
            <div id="filters" class="filters">
              <a href="#" data-filter="*" class="active">Home</a>
              <a href="#" data-filter=".bolo">Bolos</a>
              <a href="#" data-filter=".torta">Tortas</a>
              <a href="#" data-filter=".doce">Doces</a>
              <a href="#" data-filter=".cupcake">CupCakes</a>
            </div>
          </div>
        </div>
        <div id="portfolio-grid" class="row no-gutter" data-aos="fade-up" data-aos-delay="200">
          <div class="item torta col-sm-6 col-md-4 col-lg-4 mb-4">
            <a  class="item-wrap fancybox">
              <div class="work-info">
                <h3>Doce de Leite</h3>
                <span>Tortas</span>
              </div>
              <img class="img-fluid" src="assets/img/torta4.jpg">
            </a>
          </div>
          <div class="item cupcake col-sm-6 col-md-4 col-lg-4 mb-4">
            <a href="work-single.html" class="item-wrap fancybox">
              <div class="work-info">
                <h3>Ferrero Rocher</h3>
                <span>CupCakes</span>
              </div>
              <img class="img-fluid" src="assets/img/cupcake5.jpg">
            </a>
          </div>
          <div class="item bolo col-sm-6 col-md-4 col-lg-4 mb-4">
            <a href="work-single.html" class="item-wrap fancybox">
              <div class="work-info">
                <h3>Red Velvet</h3>
                <span>Bolos</span>
              </div>
              <img class="img-fluid" src="assets/img/bolo3.jpg">
            </a>
          </div>
          <div class="item doce col-sm-6 col-md-4 col-lg-4 mb-4">
            <a href="work-single.html" class="item-wrap fancybox">
              <div class="work-info">
                <h3>Brigadeiro de Doce de Leite</h3>
                <span>Doces</span>
              </div>
              <img class="img-fluid" src="assets/img/doce5.jpg">
            </a>
          </div>
          <div class="item cupcake col-sm-6 col-md-4 col-lg-4 mb-4">
            <a href="work-single.html" class="item-wrap fancybox">
              <div class="work-info">
                <h3>Brigadeiro</h3>
                <span>CupCakes</span>
              </div>
              <img class="img-fluid" src="assets/img/cupcake2.jpg">
            </a>
          </div>
          <div class="item bolo col-sm-6 col-md-4 col-lg-4 mb-4">
            <a href="work-single.html" class="item-wrap fancybox">
              <div class="work-info">
                <h3>Prestigio</h3>
                <span>Bolos</span>
              </div>
              <img class="img-fluid" src="assets/img/bolo4.jpg">
            </a>
          </div>
          <div class="item cupcake col-sm-6 col-md-4 col-lg-4 mb-4">
            <a href="work-single.html" class="item-wrap fancybox">
              <div class="work-info">
                <h3>Baunilha</h3>
                <span>CupCakes</span>
              </div>
              <img class="img-fluid" src="assets/img/cupcake3.jpg">
            </a>
          </div>
          <div id="portfolio-grid" class="row no-gutter" data-aos="fade-up" data-aos-delay="200">
          <div class="item torta col-sm-6 col-md-4 col-lg-4 mb-4">
            <a href="work-single.html" class="item-wrap fancybox">
              <div class="work-info">
                <h3>Banoffe</h3>
                <span>Tortas</span>
              </div>
              <img class="img-fluid" src="assets/img/torta1.jpg">
            </a>
          </div>
          <div id="portfolio-grid" class="row no-gutter" data-aos="fade-up" data-aos-delay="200">
          <div class="item torta col-sm-6 col-md-4 col-lg-4 mb-4">
            <a href="work-single.html" class="item-wrap fancybox">
              <div class="work-info">
                <h3>Limão</h3>
                <span>Tortas</span>
              </div>
              <img class="img-fluid" src="assets/img/torta2.jpg">
            </a>
          </div>
          <div id="portfolio-grid" class="row no-gutter" data-aos="fade-up" data-aos-delay="200">
          <div class="item torta col-sm-6 col-md-4 col-lg-4 mb-4">
            <a href="work-single.html" class="item-wrap fancybox">
              <div class="work-info">
                <h3>Morango</h3>
                <span>Tortas</span>
              </div>
              <img class="img-fluid" src="assets/img/torta3.jpg">
            </a>
          </div>        
          <div class="item bolo col-sm-6 col-md-4 col-lg-4 mb-4">
            <a href="work-single.html" class="item-wrap fancybox">
              <div class="work-info">
                <h3>Floresta Negra</h3>
                <span>Bolos</span>
              </div>
              <img class="img-fluid" src="assets/img/bolo5.jpg">
            </a>
          </div>
          <div class="item bolo col-sm-6 col-md-4 col-lg-4 mb-4">
            <a href="work-single.html" class="item-wrap fancybox">
              <div class="work-info">
                <h3>Brigadeiro</h3>
                <span>Bolos</span>
              </div>
              <img class="img-fluid" src="assets/img/bolo2.jpg">
            </a>
          </div>
          <div id="portfolio-grid" class="row no-gutter" data-aos="fade-up" data-aos-delay="200">
          <div class="item doce col-sm-6 col-md-4 col-lg-4 mb-4">
            <a href="work-single.html" class="item-wrap fancybox">
              <div class="work-info">
                <h3>Pão de Mel</h3>
                <span>Doces</span>
              </div>
              <img class="img-fluid" src="assets/img/doce3.jpg">
            </a>
          </div>
          <div id="portfolio-grid" class="row no-gutter" data-aos="fade-up" data-aos-delay="200">
          <div class="item doce col-sm-6 col-md-4 col-lg-4 mb-4">
            <a href="work-single.html" class="item-wrap fancybox">
              <div class="work-info">
                <h3>Brigadeiro</h3>
                <span>Doces</span>
              </div>
              <img class="img-fluid" src="assets/img/doce4.jpg">
            </a>
          </div>
          <div id="portfolio-grid" class="row no-gutter" data-aos="fade-up" data-aos-delay="200">
          <div class="item cupcake col-sm-6 col-md-4 col-lg-4 mb-4">
            <a href="work-single.html" class="item-wrap fancybox">
              <div class="work-info">
                <h3>Cranberry</h3>
                <span>CupCakes</span>
              </div>
              <img class="img-fluid" src="assets/img/cupcake1.jpg">
            </a>
          </div>
          <div id="portfolio-grid" class="row no-gutter" data-aos="fade-up" data-aos-delay="200">
          <div class="item doce col-sm-6 col-md-4 col-lg-4 mb-4">
            <a href="work-single.html" class="item-wrap fancybox">
              <div class="work-info">
                <h3>Macarrons</h3>
                <span>Doces</span>
              </div>
          </div>
        </div>
      </div>
    </section><!-- End  Works Section -->

    <!-- ======= Services Section ======= -->
    <section class="section services">
      <div class="container">
        <div class="row justify-content-center text-center mb-4">
          <div class="col-5">
            <h3 class="h3">Cárdapio</h3>
            <p>Conheça um pouco das nossas gostosuras!</p>
          </div>
        </div>
        <div class="row">

          <div class="col-12 col-sm-6 col-md-6 col-lg-3">
            <h4 class="h4 mb-2">Bolos</h4>
            <p>Sabores:</p>
            <ul class="list-unstyled list-line">
              <li>Brigadeiro</li>
              <li>Floresta Negra</li>
              <li>Prestigio</li>
              <li>Red Velvet</li>
            </ul>
          </div>
          <div class="col-12 col-sm-6 col-md-6 col-lg-3">
            <h4 class="h4 mb-2">Tortas</h4>
            <p>Sabores:</p>
            <ul class="list-unstyled list-line">
              <li>Doce de leite</li>
              <li>Limão</li>
              <li>Morango</li>
              <li>Banoffe</li>
            </ul>
          </div>
          <div class="col-12 col-sm-6 col-md-6 col-lg-3">
            <h4 class="h4 mb-2">Doces</h4>
            <p>Sabores:</p>
            <ul class="list-unstyled list-line">
              <li>Brigadeiro Gourmet</li>
              <li>Brigadeiro de doce de leite</li>
              <li>Macarrons</li>
              <li>Pão de mel</li>
            </ul>
          </div>
          <div class="col-12 col-sm-6 col-md-6 col-lg-3">
            <h4 class="h4 mb-2">CupCakes</h4>
            <p>Sabores:</p>
            <ul class="list-unstyled list-line">
              <li>Baunilha</li>
              <li>Chocolate</li>
              <li>Cranberry</li>
              <li>Ferrero Rocher</li>
            </ul>
          </div>
        </div>
      </div>
    </section><!-- End Services Section -->

    <section class="section pt-0">
      <div class="container">

        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial">
                  <img src="assets/img/donaneide.jpg" alt="Image" class="img-fluid">
                  <blockquote>
                    <p>Os ingredientes de alta qualidade fazem toda diferneça, com certeza comprarei novamente.</p>
                  </blockquote>
                  <p>&mdash; Dona Neide</p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial">
                  <img src="assets/img/joao.jpg" alt="Image" class="img-fluid">
                  <blockquote>
                    <p>É sempre muito dificil apenas escolher uma sobremesa. sempre saio com vários doces!</p>
                  </blockquote>
                  <p>&mdash; João Silva</p>
                </div>
              </div>
            </div><!-- End testimonial item -->

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer class="footer" role="contentinfo">
    <div class="container">
      <div class="row">
        <div class="col-sm-6">
          <p class="mb-1">&copy; Copyright MagicalBakery. All Rights Reserved</p>
          <div class="credits">
  
            Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
          </div>
        </div>
        <div class="col-sm-6 social text-md-end">
          <a href="#"><span class="bi bi-twitter"></span></a>
          <a href="#"><span class="bi bi-facebook"></span></a>
          <a href="#"><span class="bi bi-instagram"></span></a>
          <a href="#"><span class="bi bi-linkedin"></span></a>
        </div>
      </div>
    </div>
  </footer>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>